var x = 1;
var y = "1";
console.log(1 + x + y) //This calls the function 1 + variable x + variable y;
var t = x;
x = y;
y = t;
alert(1 + x + y);
/*
The alert will 
make a pop-up 
declaration of 
"111";
*/